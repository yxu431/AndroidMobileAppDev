package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;

import static com.example.myapplication.MainActivity.EXTRA_QUERY;

public class SearchResults extends AppCompatActivity implements CardAdapter.OnItemClickListener, CardAdapter.OnItemLongClickListener{

    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_Title = "title";
    public static final String EXTRA_ID = "id";
    public static final String EXTRA_Time = "time";
    private String keyword;

    private RecyclerView mRecyclerView;
    private CardAdapter mCardAdapter;
    private ArrayList<NewsCardItem> mNewsCardList;
    private TextView textView;
    private ImageView backIcon;

    private boolean isDrawn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);

        //back arrow button in toolbar
        backIcon = findViewById(R.id.search_backarrow);
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        //TextView textView = findViewById(R.id.query);
        Intent intent = getIntent();
        keyword = intent.getStringExtra(EXTRA_QUERY);

        //textView.setText(keyword);

        textView = findViewById(R.id.search_toolbar_title);

        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        mRecyclerView = findViewById(R.id.search_recyclerview);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(SearchResults.this));

        mNewsCardList = new ArrayList<>();

        setSearchResults(keyword);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mNewsCardList.clear();
                setSearchResults(keyword);
            }
        });

        mRecyclerView.addItemDecoration(new DividerItemDecoration(SearchResults.this,DividerItemDecoration.VERTICAL));
    }

    private void setSearchResults(String query) {
        mNewsCardList.clear();
        textView.setText("Search Results for " + keyword);
        //这里guardian后面一定要有斜杠 /
        //String url = "http://app-env.eba-htwz2edc.us-east-1.elasticbeanstalk.com/guardian/"+query;
        String url = "http://ez4enceenceence.us-east-1.elasticbeanstalk.com/guardian/" + query;
        final String defaultImg = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
        RequestQueue queue = Volley.newRequestQueue(SearchResults.this);
        StringRequest stringRequest = new Utf8StringRequest(
                StringRequest.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        JsonObject jsonObject = (JsonObject) new JsonParser().parse(response).getAsJsonObject();
                        JsonObject res = jsonObject.get("response").getAsJsonObject();
                        JsonArray results = res.get("results").getAsJsonArray();

                        for(int i=0; i<results.size(); i++){
                            JsonObject entry = results.get(i).getAsJsonObject();

                            //title
                            String webTitle = entry.get("webTitle").getAsString();


                            //get time and transform to zoneDateTime
                            String time = entry.get("webPublicationDate").getAsString();
                            time = time.substring(0,19);
                            LocalDateTime localTimeObj = null;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                localTimeObj = LocalDateTime.parse(time);
                            }
                            ZoneId zoneId = null;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                zoneId = ZoneId.of( "UTC" );
                            }
                            ZonedDateTime zdtAtUTC = null;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                zdtAtUTC = localTimeObj.atZone( zoneId );
                            }
                            ZonedDateTime zdtAtLA = null;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                zdtAtLA = zdtAtUTC
                                        .withZoneSameInstant( ZoneId.of( "America/Los_Angeles" ) );
                            }
                            //System.out.println(zdtAtUTC);
                            //System.out.println(zdtAtLA);
                            String detailTime = zdtAtLA.toString().substring(0,10);
                            String day = detailTime.substring(8,10);
                            String month = detailTime.substring(5,7);
                            String monthName = "";
                            if(month.equals("01")){
                                monthName = "Jan";
                            }else if(month.equals("02")){
                                monthName = "Feb";
                            }else if(month.equals("03")) {
                                monthName = "Mar";
                            }else if(month.equals("04")){
                                monthName = "Apr";
                            }else if(month.equals("05")){
                                monthName = "May";
                            }else if(month.equals("06")){
                                monthName = "Jun";
                            }else if(month.equals("07")){
                                monthName = "Jul";
                            }else if(month.equals("08")){
                                monthName = "Aug";
                            }else if(month.equals("09")){
                                monthName = "Sep";
                            }else if(month.equals("10")){
                                monthName = "Oct";
                            }else if(month.equals("11")){
                                monthName = "Nov";
                            }else if(month.equals("12")){
                                monthName = "Dec";
                            }
                            String year = detailTime.substring(0,4);
                            detailTime = day + " " + monthName + " " + year;

                            ZonedDateTime now = null;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                now = ZonedDateTime.now();
                            }

                            String duration = null;
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                duration = Duration.between(zdtAtLA,now).toString();
                            }
                            if(duration.contains("H")){
                                int hour = duration.indexOf("H");
                                String num = duration.substring(2,hour);
                                int numnum = Integer.parseInt(num);
                                if(numnum > 24){
                                    time = numnum/24 + "d ago";
                                }else{
                                time = num + "h ago";
                                }
                            }else if(duration.contains("M")){
                                int min = duration.indexOf("M");
                                String num = duration.substring(2,min);
                                time = num + "m ago";
                            }else if(duration.contains("S")){
                                //int second = duration.indexOf("S");
                                int dot = duration.indexOf(".");
                                String num = duration.substring(2,dot);
                                time = num + "s ago";
                            }


                            //section
                            String section = entry.get("sectionName").getAsString();


                            //id
                            String id = entry.get("id").getAsString();

                            System.out.println(webTitle);
                            //System.out.println(time);

                            //imgURL
                            String imgUrl;
                            if(entry.has("blocks")){
                                JsonObject blocks = entry.get("blocks").getAsJsonObject();
                                if(blocks.has("main")){
                                    JsonObject main = blocks.get("main").getAsJsonObject();
                                    JsonArray elements = main.get("elements").getAsJsonArray();
                                    JsonObject elementsObj = elements.get(0).getAsJsonObject();
                                    JsonArray assets = elementsObj.get("assets").getAsJsonArray();
                                    if(assets.size() != 0){
                                        JsonObject assetsObj = assets.get(0).getAsJsonObject();
                                        if(assetsObj.has("file")){
                                            String file = assetsObj.get("file").getAsString();
                                            imgUrl = file;
                                        }else{
                                            imgUrl= defaultImg;
                                        }
                                    }else{
                                        imgUrl = defaultImg;
                                    }
                                }else{
                                    imgUrl = defaultImg;
                                }

                            }else{
                                imgUrl = defaultImg;
                            }

                            mNewsCardList.add(new NewsCardItem(1,imgUrl,webTitle,section,time,detailTime,id));
                        }

                        mCardAdapter = new CardAdapter(SearchResults.this,mNewsCardList);
                        mRecyclerView.setAdapter(mCardAdapter);

                        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

                        swipeRefreshLayout.setVisibility(View.VISIBLE);

                        mCardAdapter.setOnItemClickListener(SearchResults.this);
                        mCardAdapter.setOnItemLongClickListener(SearchResults.this);
                        if(swipeRefreshLayout.isRefreshing()){
                            swipeRefreshLayout.setRefreshing(false);
                        }
                        isDrawn = true;

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(stringRequest);

    }

    @Override
    public void onStart() {
        super.onStart();
        if(isDrawn){
            mCardAdapter.notifyDataSetChanged();
        }
    }


    @Override
    public void onItemClick(int position) {
        Intent detailIntent = new Intent(SearchResults.this,Detail.class);
        NewsCardItem clickedItem = mNewsCardList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getmImageUrl());
        detailIntent.putExtra(EXTRA_Title, clickedItem.getmTitle());
        detailIntent.putExtra(EXTRA_ID, clickedItem.getmId());
        detailIntent.putExtra(EXTRA_Time, clickedItem.getmDetailTime());

        startActivity(detailIntent);

    }

    @Override
    public void onItemLongClick(final int position) {
        final NewsCardItem clickedItem = mNewsCardList.get(position);

        final Dialog dialog = new Dialog(SearchResults.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);

        ImageView imageView = (ImageView)dialog.findViewById(R.id.dialog_image);
        TextView dialogTitleText = (TextView) dialog.findViewById(R.id.dialog_title);

        ImageView twitterImg = dialog.findViewById(R.id.dialog_twitter);

        final ImageView bookmark = dialog.findViewById(R.id.dialog_bookmark);

        final String webUrl = clickedItem.getmId();
        final String webTitle = clickedItem.getmTitle();
        

        dialogTitleText.setText(clickedItem.getmTitle());
        Glide.with(SearchResults.this)
                .load(clickedItem.getmImageUrl())
                .centerCrop()
                .into(imageView);
        dialog.show();

        twitterImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent twitterIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=Check out this link:&url="+clickedItem.getmId()+"&hashtags=CSCI571NewsSearch"));
                startActivity(twitterIntent);

            }
        });

    }
}
