package com.example.myapplication;

public class NewsCardItem {
    //general
    private int mType;

    //news card
    private String mImageUrl;
    private String mTitle;
    private String mSection;
    private String mTime;
    private String mDetailTime;
    private String mId;

    //weather card
    private String mWeatherImageUrl;
    private String mCity;
    private String mState;
    private String mTemp;
    private String mSummary;


    private boolean isBookmarked;

    //news card constructor
    public NewsCardItem(int type, String imageUrl, String title, String section, String time, String detailTime, String id){
        mType = type;
        mImageUrl = imageUrl;
        mTitle = title;
        mSection = section;
        mTime = time;
        mDetailTime = detailTime;
        mId = id;
        this.isBookmarked = false;
    }

    //weather card constructor
    public NewsCardItem(String imageUrl, int type, String city, String state, String temp, String summary){
        mType = type;
        mWeatherImageUrl = imageUrl;
        mCity = city;
        mState = state;
        mTemp = temp;
        mSummary = summary;
    }
    public void setBookmarked(boolean bookmarked){
        isBookmarked = bookmarked;

    }

    public boolean isBookmarked() {
        return isBookmarked;
    }

    public String getmDetailTime() {
        return mDetailTime;
    }

    public String getmImageUrl() {
        return mImageUrl;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmSection() {
        return mSection;
    }

    public String getmTime() {
        return mTime;
    }

    public String getmId() {
        return mId;
    }

    public int getmType() {
        return mType;
    }

    public String getmWeatherImageUrl() {
        return mWeatherImageUrl;
    }

    public String getmCity() {
        return mCity;
    }

    public String getmState() {
        return mState;
    }

    public String getmTemp() {
        return mTemp;
    }

    public String getmSummary() {
        return mSummary;
    }

}
