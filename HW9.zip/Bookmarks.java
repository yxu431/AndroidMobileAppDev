package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProviders;

import android.app.Activity;
import android.app.ActivityOptions;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.example.myapplication.Detail;
import com.example.myapplication.R;
import com.example.myapplication.NewsCardItem;

public class Bookmarks extends Fragment implements BookmarkAdapter.OnItemLongClickListener{

    private BookmarksViewModel mViewModel;
    private Activity activity;
    private Context context;
    private TextView textView;
    private ConstraintLayout constraintLayout;
    private RecyclerView recyclerView;
    private List<String> keyList;
    private ArrayList<NewsCardItem> arrayList;
    private BookmarkAdapter bookmarkAdapter;

    public static Bookmarks newInstance() {
        return new Bookmarks();
    }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bookmarks_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(BookmarksViewModel.class);
        textView = activity.findViewById(R.id.bookmarkDefaultText);
        keyList = new ArrayList<>();
        constraintLayout = activity.findViewById(R.id.bookmarkContent);
        recyclerView = activity.findViewById(R.id.bookmark_recycler);
        arrayList = new ArrayList<>();

        recyclerView.addItemDecoration(new DividerItemDecoration(context, DividerItemDecoration.VERTICAL));
    }

    @Override
    public void onItemLongClick(final int position) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog);

        ImageView twitterButton = dialog.findViewById(R.id.dialog_twitter);
        final ImageView bookmarkButton = dialog.findViewById(R.id.dialog_bookmark);

        final String webUrl = arrayList.get(position).getmId();
        final String webTitle = arrayList.get(position).getmTitle();
        
        twitterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet/?text=Check out this link:&url="+webUrl+"&hashtags=CSCI571Newssearch"));
                startActivity(intent);
            }
        });

        ImageView dialogIcon = (ImageView)dialog.findViewById(R.id.dialog_image);
        Glide.with(context).load(arrayList.get(position).getmImageUrl()).centerCrop().into(dialogIcon);
        TextView dialog_title = (TextView)dialog.findViewById(R.id.dialog_title);
        dialog_title.setText(arrayList.get(position).getmTitle());
        dialog.show();
    }
}

