package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProviders;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONObject;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.view.Window.FEATURE_NO_TITLE;
import com.example.myapplication.NonFirstDecoration;

public class Home extends Fragment implements CardAdapter.OnItemClickListener, CardAdapter.OnItemLongClickListener {
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_Title = "title";
    public static final String EXTRA_ID = "id";
    public static final String EXTRA_Time = "time";

    private HomeViewModel mViewModel;

    private FusedLocationProviderClient mFusedLocationClient;

    private int locationRequestCode = 1000;
    private double wayLatitude = 0.0, wayLongitude = 0.0;
    private String weatherapikey = "c83f9974cea519160fc90a971d52dea9";
    private Activity activity;
    private Context context;
    private String city;
    private String state;
    private String webUrl;

    private SwipeRefreshLayout swipeRefreshLayout;
    private ConstraintLayout homeloading;
    private RecyclerView mRecyclerView;
    private CardAdapter mCardAdapter;
    private ArrayList<NewsCardItem> mNewsCardList;

    private RequestQueue mRequestQueue;


    public static Home newInstance() { return new Home(); }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.home_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(activity);
        homeloading = activity.findViewById(R.id.homeloading_home);
        homeloading.setVisibility(View.VISIBLE);
        swipeRefreshLayout = activity.findViewById(R.id.swipeRefreshLayout_home);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mNewsCardList.clear();
                setWeatherCard(city);
            }
        });

//        mRecyclerView = activity.findViewById(R.id.recycler_view);
//        mRecyclerView.setHasFixedSize(true);
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(context));
//
//
//        mNewsCardList = new ArrayList<>();
//        mRequestQueue = Volley.newRequestQueue(context);

        // check permission
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {

        } else {
            // already permission granted
            mRecyclerView = (RecyclerView) activity.findViewById(R.id.recycler_view_home);
            mRecyclerView.setLayoutManager(new LinearLayoutManager(context));

            mNewsCardList = new ArrayList<>();
            mFusedLocationClient.getLastLocation().addOnSuccessListener(activity, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if (location != null) {
                        wayLatitude = location.getLatitude();
                        wayLongitude = location.getLongitude();
                        System.out.println(String.format(Locale.US, "%s -- %s", wayLatitude, wayLongitude));

                        Geocoder geoCoder = new Geocoder(context, Locale.getDefault());
                        try {
                            List<Address> addresses = geoCoder.getFromLocation(wayLatitude, wayLongitude, 1);
                            String add = "";
                            if (addresses.size() > 0) {
                                city = addresses.get(0).getLocality();
                                state = addresses.get(0).getAdminArea();
                                System.out.println(city);
                                System.out.println(state);

                                //pass variable "city" to function setWeatherCard
                                setWeatherCard(city);
                                mRecyclerView.addItemDecoration(dividerItemDecoration);

                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        }

    }

    private void setWeatherCard(final String city) {
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" +city+ "&units=metric&appid=" + weatherapikey;

        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new StringRequest(
                StringRequest.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JsonObject jsonObject = (JsonObject) new JsonParser().parse(response).getAsJsonObject();
                        JsonObject main = jsonObject.get("main").getAsJsonObject();
                        JsonArray weather = jsonObject.get("weather").getAsJsonArray();
                        JsonObject weatherObj = weather.get(0).getAsJsonObject();
                        String summary = weatherObj.get("main").getAsString();

                        String imgURL;
                        if(summary.equals("Clouds")){
                            imgURL = "https://csci571.com/hw/hw9/images/android/cloudy_weather.jpg";
                        }else if(summary.equals("Clear")){
                            imgURL = "https://csci571.com/hw/hw9/images/android/clear_weather.jpg";
                        }else if(summary.equals("Snow")){
                            imgURL = "https://csci571.com/hw/hw9/images/android/snowy_weather.jpeg";
                        }else if(summary.equals("Rain")||summary.equals("Drizzle")){
                            imgURL = "https://csci571.com/hw/hw9/images/android/rainy_weather.jpg";
                        }else if(summary.equals("Thunderstorm")){
                            imgURL = "https://csci571.com/hw/hw9/images/android/thunder_weather.jpg";
                        }else {
                            imgURL = "https://csci571.com/hw/hw9/images/android/sunny_weather.jpg";
                        }

                        mNewsCardList.add(new NewsCardItem(imgURL,0,city,state,temp,summary));
                        setNewsCard();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error);
                    }
                }
        );

        queue.add(stringRequest);
    }

    //api call to guardian news, get json and filter with specific data
    private void setNewsCard() {
        //String url = "https://content.guardianapis.com/search?order-by=newest&show-fields=starRating,headline,thumbnail,short-url&api-key=2c2704a2-e9a3-4352-8135-bfe0ef87e8ea";
        String url="http://ez4enceenceence.us-east-1.elasticbeanstalk.com/guardianheadlines";

        final String defaultImg = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest stringRequest = new Utf8StringRequest(
                StringRequest.Method.GET,
                url,
                new Response.Listener<String>() {

                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onResponse(String response) {

                        JsonObject jsonObject = (JsonObject) new JsonParser().parse(response).getAsJsonObject();
                        JsonObject res = jsonObject.get("response").getAsJsonObject();
                        JsonArray results = res.get("results").getAsJsonArray();

                        //size() for array
                        for(int i=0; i<results.size(); i++){
                            JsonObject entry = results.get(i).getAsJsonObject();
                            String webTitle = entry.get("webTitle").getAsString();


                            //get time and transform to zoneDateTime
                            String time = entry.get("webPublicationDate").getAsString();
                            //substring以后才能满足用parse的时间格式
                            time = time.substring(0,19);
                            LocalDateTime localTimeObj = LocalDateTime.parse(time);
                            ZoneId zoneId = ZoneId.of( "UTC" );
                            ZonedDateTime zdtAtUTC = localTimeObj.atZone( zoneId );
                            ZonedDateTime zdtAtLA = zdtAtUTC
                                    .withZoneSameInstant( ZoneId.of( "America/Los_Angeles" ) );
                            //System.out.println(zdtAtUTC);
                            //System.out.println(zdtAtLA);
                            String detailTime = zdtAtLA.toString().substring(0,10);
                            String day = detailTime.substring(8,10);
                            String month = detailTime.substring(5,7);
                            String monthName = "";
                            if(month.equals("01")){
                                monthName = "Jan";
                            }else if(month.equals("02")){
                                monthName = "Feb";
                            }else if(month.equals("03")) {
                                monthName = "Mar";
                            }else if(month.equals("04")){
                                monthName = "Apr";
                            }else if(month.equals("05")){
                                monthName = "May";
                            }else if(month.equals("06")){
                                monthName = "Jun";
                            }else if(month.equals("07")){
                                monthName = "Jul";
                            }else if(month.equals("08")){
                                monthName = "Aug";
                            }else if(month.equals("09")){
                                monthName = "Sep";
                            }else if(month.equals("10")){
                                monthName = "Oct";
                            }else if(month.equals("11")){
                                monthName = "Nov";
                            }else if(month.equals("12")){
                                monthName = "Dec";
                            }
                            String year = detailTime.substring(0,4);
                            detailTime = day + " " + monthName + " " + year;
                            //System.out.println(detailTime);

                            ZonedDateTime now = ZonedDateTime.now();
                            //System.out.println(now);

                            String duration = Duration.between(zdtAtLA,now).toString();
                            if(duration.contains("H")){
                                int hour = duration.indexOf("H");
                                String num = duration.substring(2,hour);
                                time = num + "h ago";
                            }else if(duration.contains("M")){
                                int min = duration.indexOf("M");
                                String num = duration.substring(2,min);
                                time = num + "m ago";
                            }else if(duration.contains("S")){
                                //int second = duration.indexOf("S");
                                if(duration.contains("-")){
                                    int dot = duration.indexOf(".");
                                    String num = duration.substring(3,dot);
                                    time = num + "s ago";
                                }else {
                                    int dot = duration.indexOf(".");
                                    String num = duration.substring(2, dot);
                                    time = num + "s ago";
                                }
                            }
                            System.out.println(duration);


                            String section = entry.get("sectionName").getAsString();
                            String id = entry.get("id").getAsString();

                            JsonObject fields = entry.get("fields").getAsJsonObject();
                            String imgUrl;
                            if(fields.has("thumbnail")){
                                imgUrl = fields.get("thumbnail").getAsString();
                            }else {
                                imgUrl = defaultImg;
                            }
                            //System.out.println(webTitle);
                            System.out.println(time);
                            System.out.println(detailTime);

                            mNewsCardList.add(new NewsCardItem(1,imgUrl,webTitle,section,time,detailTime,id));

                        }


                        mCardAdapter = new CardAdapter(context,mNewsCardList);
                        mRecyclerView.setAdapter(mCardAdapter);


                        swipeRefreshLayout.setVisibility(View.VISIBLE);

                        mCardAdapter.setOnItemClickListener(Home.this);
                        mCardAdapter.setOnItemLongClickListener(Home.this);

                        if(swipeRefreshLayout.isRefreshing()){
                            swipeRefreshLayout.setRefreshing(false);
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
        queue.add(stringRequest);

    }

    @Override
    public void onStart() {
        super.onStart();
        if(isDrawn){
            mCardAdapter.notifyDataSetChanged();
        }
    }

    //这里是处理当第一次打开程序 软件获取地理位置信息的权限的时候
    //这里也要使用setWeather方法 不然会在改变手机地理位置信息之后不显示结果
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1000: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    mFusedLocationClient.getLastLocation().addOnSuccessListener(activity, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {

                            mRecyclerView = (RecyclerView) activity.findViewById(R.id.recycler_view_home);
                            mRecyclerView.setLayoutManager(new LinearLayoutManager(context));

                            mNewsCardList = new ArrayList<>();

                            if (location != null) {
                                wayLatitude = location.getLatitude();
                                wayLongitude = location.getLongitude();;
                                System.out.println(String.format(Locale.US, "%s -- %s", wayLatitude, wayLongitude));
                                Geocoder geoCoder = new Geocoder(context, Locale.getDefault());
                                try {
                                    List<Address> addresses = geoCoder.getFromLocation(wayLatitude, wayLongitude, 1);
                                    String add = "";
                                    if (addresses.size() > 0) {
                                        city = addresses.get(0).getLocality();
                                        state = addresses.get(0).getAdminArea();
                                        System.out.println(city);
                                        System.out.println(state);

                                        //pass variable "city" to function setWeatherCard
                                        setWeatherCard(city);

                                        RecyclerView.ItemDecoration dividerItemDecoration = new NonFirstDecoration(ContextCompat.getDrawable(context,R.drawable.divider));
                                        mRecyclerView.addItemDecoration(dividerItemDecoration);

                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    });
                } else {

                }
                break;
            }
        }
    }

    @Override
    public void onItemClick(int position) {
        Intent detailIntent = new Intent(context,Detail.class);
        NewsCardItem clickedItem = mNewsCardList.get(position);

        detailIntent.putExtra(EXTRA_URL, clickedItem.getmImageUrl());
        detailIntent.putExtra(EXTRA_Title, clickedItem.getmTitle());
        detailIntent.putExtra(EXTRA_ID, clickedItem.getmId());
        detailIntent.putExtra(EXTRA_Time, clickedItem.getmDetailTime());

        startActivity(detailIntent);

    }
}
