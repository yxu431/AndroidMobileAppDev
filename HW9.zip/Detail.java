package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.text.Html;
import android.transition.Slide;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import static com.example.myapplication.Home.EXTRA_ID;
import static com.example.myapplication.Home.EXTRA_Time;
//import static com.example.myapplication.Home.EXTRA_Title;
import static com.example.myapplication.Home.EXTRA_URL;

public class Detail extends AppCompatActivity {

    private ProgressBar spinner;
    private ImageView backIcon;
    private ImageView twitter;

    private SharedPreferences preferences;
    private ImageView bookmark;
    private String news_id;
    private String news_url;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        setContentView(R.layout.activity_detail);
        getWindow().setEnterTransition(new Slide().setDuration(200));
        getWindow().setExitTransition(new Slide().setDuration(200));

        //back arrow button in toolbar
        backIcon = findViewById(R.id.backarrow);
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        twitter = findViewById(R.id.detail_twitter);
        

        Intent intent = getIntent();
        news_url = intent.getStringExtra(EXTRA_URL);
        news_id = intent.getStringExtra(EXTRA_ID);
        String news_time = intent.getStringExtra(EXTRA_Time);

        setDetailCard(news_id, news_url,news_time);
    }


    private void setDetailCard(String id, final String imgurl, final String newstime) {
        //System.out.println("this is detail");
        //System.out.println(id);
        final String url = "https://content.guardianapis.com/"+id+"?api-key=2c2704a2-e9a3-4352-8135-bfe0ef87e8ea&show-blocks=all";
        final String defaultImg = "https://assets.guim.co.uk/images/eada8aa27c12fe2d5afa3a89d3fbae0d/fallback-logo.png";
        RequestQueue queue = Volley.newRequestQueue(Detail.this);
        StringRequest stringRequest = new Utf8StringRequest(
                StringRequest.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JsonObject jsonObject = (JsonObject) new JsonParser().parse(response).getAsJsonObject();
                        JsonObject res = jsonObject.get("response").getAsJsonObject();
                        JsonObject content = res.get("content").getAsJsonObject();


                        //news title
                        final String webTitle = content.get("webTitle").getAsString();

                        //news description
                        JsonObject blocks = content.get("blocks").getAsJsonObject();
                        JsonArray body = blocks.get("body").getAsJsonArray();
                        JsonObject entry;
                        String bodyHtml = "";
                        for(int i =0; i<body.size(); i++){
                            entry = body.get(i).getAsJsonObject();
                            bodyHtml = bodyHtml + entry.get("bodyHtml").getAsString();
                        }

                        //article URL
                        final String webUrl = content.get("webUrl").getAsString();

                        //view full article
                        TextView viewFull = findViewById(R.id.viewFull);
                        //underline
                        viewFull.setText(Html.fromHtml("<u>"+"View Full Article"+"</u>"));
                        viewFull.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent viewIntent =
                                        new Intent("android.intent.action.VIEW",
                                                Uri.parse(webUrl));
                                startActivity(viewIntent);
                            }
                        });
                        System.out.println(webUrl);
                        final String section = content.get("sectionName").getAsString();

                        //news date
                        //String date = content.get("webPublicationDate").getAsString();

                        //draw detail card
                        //spinner = (ProgressBar)findViewById(R.id.progressBar1);
                        ConstraintLayout loading = findViewById(R.id.loading);
                        ScrollView detail = findViewById(R.id.detailView);

                        ImageView imageView = findViewById(R.id.detail_img);
                        TextView titleText = findViewById(R.id.detail_title);
                        TextView desText = findViewById(R.id.detail_des);
                        TextView sectionText = findViewById(R.id.detail_section);
                        TextView dateText = findViewById(R.id.detail_date);
                        TextView toolbarTitleText = findViewById(R.id.toolbar_title);

                        desText.setText(Html.fromHtml(bodyHtml));
                        titleText.setText(webTitle);
                        sectionText.setText(section);
                        dateText.setText(newstime);
                        toolbarTitleText.setText(webTitle);

                        Glide.with(Detail.this)
                                .load(imgurl)
                                .centerCrop()
                                .into(imageView);

                        loading.setVisibility(View.GONE);
                        detail.setVisibility(View.VISIBLE);

                        twitter.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent twitterIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/intent/tweet?text=Check out this link:&url="+webUrl+"&hashtags=CSCI571NewsSearch"));
                                startActivity(twitterIntent);

                            }
                        });


                        System.out.println(webTitle);
                        System.out.println(bodyHtml);
                        //System.out.println(imageUrl);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(stringRequest);

    }
}
