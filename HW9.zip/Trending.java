package com.example.myapplication;

import androidx.lifecycle.ViewModelProviders;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;

import static com.example.myapplication.MainActivity.EXTRA_QUERY;

public class Trending extends Fragment {
    private Activity activity;
    private Context context;
    private EditText editText;
    private List<Entry> list;
    private LineChart lineChart;

    private TrendingViewModel mViewModel;

    public static Trending newInstance() { return new Trending(); }


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.trending_fragment, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(TrendingViewModel.class);
        // TODO: Use the ViewModel

        editText = activity.findViewById(R.id.trending_input);
        lineChart = activity.findViewById(R.id.lineChart);

        editText.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    // Perform action on key press
                    //System.out.println(editText.getText());
                    String input = editText.getText().toString();
                    getGoogleTrends(input);
                    return true;
                }
                return false;
            }
        });

    }

    private void getGoogleTrends(final String input) {
        list = new ArrayList<>();
        //这里为什么googleTrends后面一定要加一个斜杠 /
        //String url = "http://ez4enceenceence.us-east-1.elasticbeanstalk.com/googleTrends/" + input;
        String url = "http://ez4enceenceence.us-east-1.elasticbeanstalk.com/googleTrends/" + input;
        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest(
                StringRequest.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JsonObject jsonObject = (JsonObject) new JsonParser().parse(response).getAsJsonObject();
                        JsonObject def = jsonObject.get("default").getAsJsonObject();
                        JsonArray timelineData = def.get("timelineData").getAsJsonArray();

                        for(int i=0; i<timelineData.size(); i++){
                            JsonObject entry = timelineData.get(i).getAsJsonObject();

                            JsonArray valueArray = entry.get("value").getAsJsonArray();

                            float value = valueArray.get(0).getAsFloat();
                            float x = i;
                            list.add(new Entry(x,value));

                            System.out.println(value);
                        }
                        Legend legend = lineChart.getLegend();
        

                        LineDataSet lineDataSet = new LineDataSet(list, "Trending chart for " + input );
        
                        List<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
                        dataSets.add(lineDataSet);

                        LineData data = new LineData(dataSets);
                        lineChart.setData(data);
                        lineChart.invalidate();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println(error);
                    }
                }
        );
        queue.add(stringRequest);
    }

}
