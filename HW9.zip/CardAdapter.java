package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.gson.Gson;

import java.util.ArrayList;

public class CardAdapter extends RecyclerView.Adapter {
    private Context context;
    //private Activity mActivity;
    private ArrayList<NewsCardItem> mNewsCardList;

    private OnItemClickListener mListener;
    private OnItemLongClickListener mLongListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        mLongListener = listener;
    }

    
    public CardAdapter(Context context, ArrayList<NewsCardItem> newsCardList) {
        this.context = context;
        //mActivity = activity;
        mNewsCardList = newsCardList;
    }

    @Override
    public int getItemViewType(int position) {
        return mNewsCardList.get(position).getmType();
    }
    // 1 is news card
    // 0 is weather card

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v;
        if(viewType == 0){
            v = LayoutInflater.from(context).inflate(R.layout.weather_card,parent,false);
            return new WeatherCardViewHolder(v);
        }
        v = LayoutInflater.from(context).inflate(R.layout.news_card,parent,false);
        return new NewsCardViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if(mNewsCardList.get(position).getmType() == 1){
            //bind news card
            final NewsCardViewHolder newsCardViewHolder = (NewsCardViewHolder) holder;
            final NewsCardItem currentNewsCard = mNewsCardList.get(position);
            final String webUrl = currentNewsCard.getmId();
            final String webTitle = currentNewsCard.getmTitle();

            newsCardViewHolder.mTitle.setText(mNewsCardList.get(position).getmTitle());
            newsCardViewHolder.mSection.setText(mNewsCardList.get(position).getmSection());
            newsCardViewHolder.mTime.setText(mNewsCardList.get(position).getmTime());


            Glide.with(context)
                    .load(mNewsCardList.get(position).getmImageUrl())
                    .centerCrop()
                    .into(((NewsCardViewHolder) holder).mImageView);
                    
        }

    @Override
    public int getItemCount() {
        return mNewsCardList.size();
    }

    public class NewsCardViewHolder extends RecyclerView.ViewHolder{
        ImageView mImageView, mBookmark;
        TextView mTitle, mSection, mTime, mId;

        public NewsCardViewHolder(@NonNull View itemView) {
            super(itemView);

            mImageView = itemView.findViewById(R.id.news_img);
            mTitle = itemView.findViewById(R.id.news_title);
            mSection = itemView.findViewById(R.id.news_section);
            mTime = itemView.findViewById(R.id.news_time);
            mBookmark = itemView.findViewById(R.id.news_bookmark);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mListener != null) {
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position);
                        }
                    }
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if(mLongListener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            mLongListener.onItemLongClick(position);
                        }
                    }
                    return false;
                }
            });
        }
    }

    public class WeatherCardViewHolder extends RecyclerView.ViewHolder{
        ImageView mImageView;
        TextView mCity, mState, mTemp, mSummary;

        public WeatherCardViewHolder(@NonNull View itemView) {
            super(itemView);

            mImageView = itemView.findViewById(R.id.background);
            mCity = itemView.findViewById(R.id.city);
            mState = itemView.findViewById(R.id.state);
            mTemp = itemView.findViewById(R.id.temp);
            mSummary = itemView.findViewById(R.id.summary);
        }
    }
}
